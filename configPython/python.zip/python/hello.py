#!/usr/bin/env python3
print ('hello, Python')
print ('hello, Python, my first engineering')